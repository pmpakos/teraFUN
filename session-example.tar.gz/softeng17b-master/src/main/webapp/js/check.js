/*******************************************************************************
 * 
 * Javascript code file!
 * 
 ******************************************************************************/

var xmlhttp;

function loadDoc(url) {
	xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = onComplete;
	xmlhttp.open("GET", url, true);
	xmlhttp.send(null);
}

function onComplete(event) {
	if (xmlhttp.readyState == 4)
		writeContent(xmlhttp.responseText);
}

function writeContent(data) {
	document.getElementById("content").innerHTML = data;
}

function asyncLoadContent(url) {
	writeContent("Please Wait<br/>Loading...");
	loadDoc(url, writeContent);
}

function submit_form() {

	var form = document.getElementById("contactForm");
	var ok = true;

	if (form.exampleInput1.value.length < 2) {
		ok = false;
		alert("Too short name.");
	}

	return ok;
}

function register_form(){
	var form= document.getElementById("signUpForm");
	
	if(form.password.value.length < 5){
		alert("password too short");
	}
	else if(form.username.value == 'Alex'){
		//Se anti8esh me to alert box to promtbox perimenei kai eisodo sto 2o orisma.. to apotelesma
		prompt("please select a different username","...");
	}
	else{
		//to confirm box epistrefei true 'h false kai mporoyme na to epe3ergastoume peraiterw
		confirm("Are you sure you want to register ?");
	}			
}
