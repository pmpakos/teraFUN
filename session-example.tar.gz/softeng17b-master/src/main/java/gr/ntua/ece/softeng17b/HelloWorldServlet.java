package gr.ntua.ece.softeng17b;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import javax.servlet.http.HttpSession;

import gr.ntua.ece.softeng17b.conf.*;
import gr.ntua.ece.softeng17b.data.*;
/**
 * Servlet implementation class LoginServlet
 */

public class HelloWorldServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HelloWorldServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("email");
		String password = request.getParameter("password");
		//String username="silvia";
		//String password="123";
		 System.out.println("username: " + username);
	        System.out.println("password: " + password);
	 
	        // do some processing here...
	        

	        Configuration conf = Configuration.getInstance();
	        DataAccess dataAccess = Configuration.getInstance().getDataAccess();
	        ParentDAO parent_dao = new ParentDAO();

			parent_dao.setDataSource(dataAccess.dataSource);
			parent_dao.setJdbcTemplate(dataAccess.jdbcTemplate);


	        boolean check_parent = parent_dao.login(username, password);
	        //boolean check_company = company_dao.login(username, password);
	        //boolean check_admin = admin_dao.login(username, password);
	        PrintWriter writer = response.getWriter();
	        String htmlRespone;
	        if(check_parent){
		        // build HTML code
		        HttpSession session = request.getSession();
				session.setAttribute("username", username);
				if(check_parent){
					session.setAttribute("permissions","0");
				}
				response.sendRedirect("main.jsp");
		        //r1equest.getRequestDispatcher("main.jsp").forward(request, response);
	        }
	        else{
	        	htmlRespone = "<html>";
		        htmlRespone += "<h2>Error!! " + username + "</h2>";     
		        htmlRespone += "</html>";
		        writer.println(htmlRespone);
	        }


	        // get response writer
	        
	         
	        // return response
	        
		
		doGet(request, response);
	}

}