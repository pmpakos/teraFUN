package gr.ntua.ece.softeng17b.data;

public class Parent {

	int ParentID;
	String Username;
	String FirstName;
	String LastName;
	String Address;
	int PostalCode;
	int TelephoneNumber;
	String Email;
	String Password;
	int Status;
	int CounterEvents;
	int Points;
	String BankAccount;
	String XPosition;
	String YPosition;
	
	public Parent(int ID, String Username, String FirstName, String LastName, 
						String Address, int PostalCode, int TelephoneNumber, 
						String Email, String Password, int Status, 
						int CounterEvents, int Points, String BankAccount, 
						String XPosition, String YPosition){
		this.ParentID = ID;
		this.Username = Username;
		this.FirstName = FirstName;
		this.LastName = LastName;
		this.Address = Address;
		this.PostalCode = PostalCode;
		this.TelephoneNumber = TelephoneNumber;
		this.Email = Email;
		this.Password = Password;
		this.Status = Status;
		this.CounterEvents = CounterEvents;
		this.Points = Points;
		this.BankAccount = BankAccount;
		this.XPosition = XPosition;
		this.YPosition = YPosition;
	}
	
	public int getParentID(){
		return this.ParentID;
	}
	
	public String getFirstName(){
		return this.FirstName;
	}
	
	public String getLastName(){
		return this.LastName;
	}
	
	public String getEmail(){
		return this.Email;
	}
	
	public String getPassword(){
		return this.Password;
	}
}