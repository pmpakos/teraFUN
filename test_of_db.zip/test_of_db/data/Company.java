package gr.ntua.ece.softeng17b.data;

public class Company {

	int CompanyID;
	String Username;
	String CompanyName;
	String Address;
	int PostalCode;
	int TelephoneNumber;
	String Email;
	int AFM;
	String Password;
	int BankAccount;
	String Description;
	int Status;
	int Points;
	String XPosition;
	String YPosition;
	
	public Company (int ID, String Username, String CompanyName, String Address,
	int PostalCode,	int TelephoneNumber, String Email, int AFM, String Password, int BankAccount, 	String Description, int Status, int Points,	String XPosition, String YPosition){
		
		this.CompanyID = ID;
		this.Username = Username;
		this.CompanyName = CompanyName;
		this.Address = Address;
		this.PostalCode = PostalCode;
		this.TelephoneNumber = TelephoneNumber;
		this.Email = Email;
		this.AFM = AFM;
		this.Password = Password;
		this.BankAccount = BankAccount;
		this.Description = Description;
		this.Status = Status;
		this.Points = Points;
		this.XPosition = XPosition;
		this.YPosition = YPosition;
	}
	
	public int getCompanyID(){
		return this.CompanyID;
	}
	
	public String getCompanyName(){
		return this.CompanyName;
	}
	
	
	public String getEmail(){
		return this.Email;
	}
	
	public String getPassword(){
		return this.Password;
	}
}